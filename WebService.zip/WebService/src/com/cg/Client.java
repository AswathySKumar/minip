package com.cg;

import java.net.MalformedURLException;
import java.net.URL;



import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Client {
	public static void main(String[] args) throws Exception  {
		URL url=new URL("http://127.0.0.1:9878/cs?wsdl");
		QName qname=new QName("http://cg.com/","CalculatorService");
		Service service=Service.create(url,qname);
		CalculatorServer endPointIntf=service.getPort(CalculatorServer.class);
		Scanner scan=new Scanner(System.in);
		System.out.println("enter values");
		int param1=scan.nextInt();
		int param2=scan.nextInt();
		System.out.println("Addition="+endPointIntf.addition(param1, param2));
		System.out.println("Subtraction="+endPointIntf.subtraction(param1, param2));
		System.out.println("division="+endPointIntf.division(param1, param2));
		System.out.println("modulus="+endPointIntf.modulus(param1, param2));
		System.out.println("multiplication="+endPointIntf.multiplication(param1, param2));
		
		
	}

}
