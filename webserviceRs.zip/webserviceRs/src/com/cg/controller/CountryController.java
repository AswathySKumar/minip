package com.cg.controller;

import java.util.List;




import javax.websocket.server.PathParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.bean.Country;
import com.cg.service.CountryServiceImpl;
import com.cg.service.ICountryService;

public class CountryController {
	ICountryService countryservice;

	public CountryController() {
		countryservice=new CountryServiceImpl();
	}
@GET
@Produces(MediaType.APPLICATION_JSON)
public List<Country> getCountries(){
	List<Country> listOfCountries=countryservice.getALLCountries();
	return listOfCountries;
}
@GET
@Path("{/id}")
public Country getCountriesById(@PathParam("id") int id){

	return countryservice.getCountry(id);
}
@POST
@Produces(MediaType.APPLICATION_JSON)
public Country addCountry(@FormParam("txtId") int txtId,
		@FormParam("txtName") String txtName,
		@FormParam("txtPopulation") int txtPopulation) {
	Country country = new Country();
	country.setCountryid(txtId);
	country.setCountryname(txtName);

	country.setPopulation(txtPopulation);
	return countryservice.addCountry(country);
}

/**
 * Method to delete a country,supporting HTTP POST method, here we are using
 * POST to support delete produces Media type of JSON
 * 
 * @param id
 * @return Country
 */
@POST
@Path("/delete")
@Produces(MediaType.APPLICATION_JSON)
public Country deleteCountry(@FormParam("txtId") int id) {
	Country country = countryservice.deleteCountry(id);
	// if valid country Id is existing then country gets deleted; otherwise
	// returning a JSON object with default (null) values
	if (country != null) {
		return country;
	} else {
		return new Country();
	}

}
}
