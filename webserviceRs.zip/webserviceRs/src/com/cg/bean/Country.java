package com.cg.bean;

public class Country {
	private int countryid;
	private String countryname;
	private int population;
	public int getCountryid() {
		return countryid;
	}
	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}
	public String getCountryname() {
		return countryname;
	}
	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}
	public int getPopulation() {
		return population;
	}
	public void setPopulation(int population) {
		this.population = population;
	}
	public Country(int countryid, String countryname, int population) {
		super();
		this.countryid = countryid;
		this.countryname = countryname;
		this.population = population;
	}
	public Country() {
		// TODO Auto-generated constructor stub
	}
	

}
