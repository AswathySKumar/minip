package com.cg.dao;

import java.util.List;

import com.cg.bean.Country;

public interface ICountrydao {
	public List<Country> getALLCountries();
	public Country getCountry(int id);
	public Country addCountry(Country country);
	public Country deleteCountry(int id);
	

}
