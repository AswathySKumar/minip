package com.cg.dao;

import java.util.List;

import com.cg.bean.Country;

public class CountrydaoImpl implements ICountrydao{

	@Override
	public List<Country> getALLCountries() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Country getCountry(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Country addCountry(Country country) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Country deleteCountry(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
