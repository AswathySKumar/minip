package com.cg.service;

import java.util.List;

import com.cg.bean.Country;
import com.cg.dao.ICountrydao;

public class CountryServiceImpl implements ICountryService{
	private ICountrydao countrydao;

	@Override
	public List<Country> getALLCountries() {
		// TODO Auto-generated method stub
		return countrydao.getALLCountries();
	}

	@Override
	public Country getCountry(int id) {
		// TODO Auto-generated method stub
		return countrydao.getCountry(id);
	}

	@Override
	public Country addCountry(Country country) {
		// TODO Auto-generated method stub
		return countrydao.addCountry(country);
	}

	@Override
	public Country deleteCountry(int id) {
		// TODO Auto-generated method stub
		return countrydao.deleteCountry(id);
	}

}
